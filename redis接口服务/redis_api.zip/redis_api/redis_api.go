package main

import (
    "context"
    "fmt"
    "io/ioutil"
    "net/http"
    "sync"

    "github.com/go-redis/redis/v8"
    "github.com/sirupsen/logrus"
)

var (
    redisClient *redis.Client
    wg         sync.WaitGroup
    ch         chan struct{}
    logger     *logrus.Logger
)

func init() {
    redisClient = redis.NewClient(&redis.Options{
        Addr:     "127.0.0.1:6379",
        Password: "",
        DB:       0,
    })

    // 测试 Redis 连接
    _, err := redisClient.Ping(context.Background()).Result()
    if err!= nil {
        logrus.Fatalf("Failed to connect to Redis: %v", err)
    }

    ch = make(chan struct{}, 100) // 控制并发数为 100，可根据实际情况调整
    logger = logrus.New()
    logger.SetFormatter(&logrus.TextFormatter{})
    logger.Info("Redis client initialized and connection established.")
}

func main() {
    http.HandleFunc("/receive", receiveHandler)
    logger.Info("Starting server on :8088")
    logrus.Fatal(http.ListenAndServe("0.0.0.0:8088", nil))
}

func receiveHandler(w http.ResponseWriter, r *http.Request) {
    if r.Method!= http.MethodPost {
        logger.Warn("Invalid method, only POST is allowed")
        http.Error(w, "Invalid method, only POST is allowed", http.StatusMethodNotAllowed)
        return
    }

    body, err := ioutil.ReadAll(r.Body)
    if err!= nil {
        logger.Errorf("Failed to read request body: %v", err)
        http.Error(w, "Failed to read request body", http.StatusInternalServerError)
        return
    }
    defer r.Body.Close()
    logger.WithField("length", len(body)).Info("Received request body")

    ch <- struct{}{}
    wg.Add(1)
    go func() {
        defer wg.Done()
        defer func() { <-ch }()
        err := storeData(body)
        if err!= nil {
            logger.Errorf("Failed to store data in Redis: %v. Discarding data.", err)
        } else {
            logger.Info("Data stored successfully in Redis.")
        }
    }()

    w.WriteHeader(http.StatusOK)
    fmt.Fprintln(w, "Data received and will be stored in Redis")
}

func storeData(data []byte) error {
    channelName := "packet_channel"
    publishResult := redisClient.Publish(context.Background(), channelName, string(data))
    if publishResult.Err()!= nil {
        logger.Errorf("Failed to publish data to channel %s: %v", channelName, publishResult.Err())
        return publishResult.Err()
    }
    logger.WithField("subscribers", publishResult.Val()).Infof("Message published to channel %s", channelName)
    return nil
}